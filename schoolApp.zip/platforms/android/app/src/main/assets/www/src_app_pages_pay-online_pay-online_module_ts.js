(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_pay-online_pay-online_module_ts"],{

/***/ 2972:
/*!***************************************************************!*\
  !*** ./src/app/pages/pay-online/pay-online-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayOnlinePageRoutingModule": () => (/* binding */ PayOnlinePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _pay_online_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pay-online.page */ 3091);




const routes = [
    {
        path: '',
        component: _pay_online_page__WEBPACK_IMPORTED_MODULE_0__.PayOnlinePage
    }
];
let PayOnlinePageRoutingModule = class PayOnlinePageRoutingModule {
};
PayOnlinePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PayOnlinePageRoutingModule);



/***/ }),

/***/ 518:
/*!*******************************************************!*\
  !*** ./src/app/pages/pay-online/pay-online.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayOnlinePageModule": () => (/* binding */ PayOnlinePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _pay_online_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pay-online-routing.module */ 2972);
/* harmony import */ var _pay_online_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pay-online.page */ 3091);







let PayOnlinePageModule = class PayOnlinePageModule {
};
PayOnlinePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pay_online_routing_module__WEBPACK_IMPORTED_MODULE_0__.PayOnlinePageRoutingModule
        ],
        declarations: [_pay_online_page__WEBPACK_IMPORTED_MODULE_1__.PayOnlinePage]
    })
], PayOnlinePageModule);



/***/ }),

/***/ 3091:
/*!*****************************************************!*\
  !*** ./src/app/pages/pay-online/pay-online.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayOnlinePage": () => (/* binding */ PayOnlinePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_pay_online_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./pay-online.page.html */ 9991);
/* harmony import */ var _pay_online_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pay-online.page.scss */ 4304);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let PayOnlinePage = class PayOnlinePage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    changeMethod(val) {
        this.id = val;
    }
    goBack() {
        this._router.navigate(['/home']);
    }
};
PayOnlinePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
PayOnlinePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-pay-online',
        template: _raw_loader_pay_online_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pay_online_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PayOnlinePage);



/***/ }),

/***/ 4304:
/*!*******************************************************!*\
  !*** ./src/app/pages/pay-online/pay-online.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top ion-label {\n  color: #fff;\n  font-size: 22px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .top .button ion-button {\n  --background:#fff;\n  color: #2855ae;\n  --border-radius:25px;\n  --padding-end:30px;\n  --padding-start:30px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: auto;\n  min-height: calc(100% - 80px);\n}\nion-content .content_div .main_content_div {\n  width: 100%;\n  padding: 20px;\n}\nion-content .content_div .main_content_div ion-label {\n  display: block;\n  margin-top: 20px;\n  color: gray;\n}\nion-content .content_div .main_content_div .square_div {\n  background: whitesmoke;\n  width: 100%;\n  height: 100px;\n  position: relative;\n}\nion-content .content_div .main_content_div .yellow {\n  background: linear-gradient(#7292cf, #2855ae);\n}\nion-content .content_div .main_content_div .gray_img {\n  width: 50px;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\nion-content .content_div .main_content_div ion-input, ion-content .content_div .main_content_div ion-datetime {\n  border: 1px solid lightgray;\n  border-radius: 5px;\n  --padding-start:8px;\n  margin-top: 15px;\n}\nion-content .content_div .main_content_div .left_col {\n  padding-left: 0px;\n}\nion-content .content_div .main_content_div .right_col {\n  padding-right: 0px;\n}\nion-content .content_div .main_content_div ion-button {\n  --background:linear-gradient(#7292cf,#2855ae );\n  --border-radius:5px;\n  color: white;\n  margin-top: 30px;\n}\nion-content .content_div .doller {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  background: linear-gradient(#7292cf, #2855ae);\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheS1vbmxpbmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHlGQUFBO0FBQ1I7RUFDSSxrQ0FBQTtFQUNBLDhDQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFEUTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FBR1o7QUFEUTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUdaO0FBQ1k7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBQ2hCO0FBSVk7RUFDSSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7QUFGaEI7QUFPSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0FBTFI7QUFNUTtFQUNJLFdBQUE7RUFDQSxhQUFBO0FBSlo7QUFNWTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUFKaEI7QUFPWTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQUxoQjtBQVFZO0VBQ0ksNkNBQUE7QUFOaEI7QUFTWTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0VBQ0EsZ0NBQUE7QUFQaEI7QUFVWTtFQUNJLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBUmhCO0FBV1k7RUFDSSxpQkFBQTtBQVRoQjtBQVlZO0VBQ0ksa0JBQUE7QUFWaEI7QUFhWTtFQUNJLDhDQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFYaEI7QUFjUTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBWloiLCJmaWxlIjoicGF5LW9ubGluZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Qb3BwaW5zOndnaHRANDAwOzYwMCZkaXNwbGF5PXN3YXAnKTtcclxuaW9uLWNvbnRlbnR7XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgLS1iYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgjNzI5MmNmLCMyODU1YWUgKTtcclxuICAgIC50b3B7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgIG1hcmdpbi10b3A6NDBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgY29sb3I6I2ZmZjtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuYmFja19kaXZ7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgY29sb3I6I2ZmZjtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToyNXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjIwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5idXR0b257XHJcbiAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6I2ZmZjtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiMyODU1YWU7XHJcbiAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6MjVweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6MzBweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDozMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzVweDtcclxuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MjVweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLWJvdHRvbTo1MHB4O1xyXG4gICAgICAgIGhlaWdodDphdXRvO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IGNhbGMoMTAwJSAtIDgwcHgpO1xyXG4gICAgICAgIC5tYWluX2NvbnRlbnRfZGl2e1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6MjBweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgLnNxdWFyZV9kaXZ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOndoaXRlc21va2U7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIC55ZWxsb3d7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgLmdyYXlfaW1ne1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6NTBweDtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIGxlZnQ6NTAlO1xyXG4gICAgICAgICAgICAgICAgdG9wOjUwJTtcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgaW9uLWlucHV0LGlvbi1kYXRldGltZXtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjoxcHggc29saWQgIGxpZ2h0Z3JheTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDo4cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOjE1cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgLmxlZnRfY29se1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgICAgICAucmlnaHRfY29se1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDowcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6NXB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOjMwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLmRvbGxlcntcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG59Il19 */");

/***/ }),

/***/ 9991:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pay-online/pay-online.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div>\n      <div class=\"back_div\">\n        <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n        <ion-label>Pay Now !</ion-label>\n      </div>\n    </div>\n\n  </div>\n\n  <div class=\"content_div\">\n\n    <div class=\"main_content_div\">\n      <ion-label>1. Select Your Payment Method</ion-label>\n      <ion-row style=\"margin-top:20px;\">\n        <ion-col size=\"4\">\n          <div class=\"square_div\" (click)=\"changeMethod(1)\" [class.yellow]=\"id ==1\">\n            <img class=\"gray_img\" *ngIf=\"id !=1\" src=\"../../../../assets/card2.png\" />\n            <img class=\"gray_img\" *ngIf=\"id ==1\" src=\"../../../../assets/card1.png\" />\n          </div>\n\n        </ion-col>\n\n\n        <ion-col size=\"4\">\n          <div class=\"square_div\" (click)=\"changeMethod(2)\" [class.yellow]=\"id ==2\">\n            <img class=\"gray_img\" *ngIf=\"id !=2\" src=\"../../../../assets/money2.png\" />\n            <img class=\"gray_img\" *ngIf=\"id ==2\" src=\"../../../../assets/money1.png\" />\n          </div>\n\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <div class=\"square_div\" (click)=\"changeMethod(3)\" [class.yellow]=\"id ==3\">\n            <img class=\"gray_img\" *ngIf=\"id !=3\" src=\"../../../../assets/paypal1.png\" />\n            <img class=\"gray_img\" *ngIf=\"id ==3\" src=\"../../../../assets/paypal2.png\" />\n          </div>\n\n        </ion-col>\n      </ion-row>\n\n      <ion-label>2. Enter Your Card Details</ion-label>\n      <ion-label>Card Number</ion-label>\n\n      <ion-input type=\"text\" placeholder=\"XXXX-XXXX-XXXX-1212\"></ion-input>\n\n      <ion-row>\n        <ion-col size=\"4\" class=\"left_col\">\n          <ion-datetime display-format=\"MM\" placeholder=\"MM\"></ion-datetime>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-datetime display-format=\"YYYY\" placeholder=\"YYYY\"></ion-datetime>\n        </ion-col>\n\n        <ion-col size=\"4\" class=\"right_col\">\n          <ion-input type=\"text\" placeholder=\"CVV\"></ion-input>\n        </ion-col>\n      </ion-row>\n\n      <ion-button expand=\"block\" fill=\"clear\" shape=\"round\">Confirm</ion-button>\n    </div>\n\n    <div class=\"doller\">\n      <p>Total : <span>$100</span></p>\n    </div>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pay-online_pay-online_module_ts.js.map