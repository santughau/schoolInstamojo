(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_timetable_timetable_module_ts"],{

/***/ 6980:
/*!*************************************************************!*\
  !*** ./src/app/pages/timetable/timetable-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimetablePageRoutingModule": () => (/* binding */ TimetablePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _timetable_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./timetable.page */ 7583);




const routes = [
    {
        path: '',
        component: _timetable_page__WEBPACK_IMPORTED_MODULE_0__.TimetablePage
    }
];
let TimetablePageRoutingModule = class TimetablePageRoutingModule {
};
TimetablePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TimetablePageRoutingModule);



/***/ }),

/***/ 2697:
/*!*****************************************************!*\
  !*** ./src/app/pages/timetable/timetable.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimetablePageModule": () => (/* binding */ TimetablePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _timetable_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./timetable-routing.module */ 6980);
/* harmony import */ var _timetable_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timetable.page */ 7583);







let TimetablePageModule = class TimetablePageModule {
};
TimetablePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _timetable_routing_module__WEBPACK_IMPORTED_MODULE_0__.TimetablePageRoutingModule
        ],
        declarations: [_timetable_page__WEBPACK_IMPORTED_MODULE_1__.TimetablePage]
    })
], TimetablePageModule);



/***/ }),

/***/ 7583:
/*!***************************************************!*\
  !*** ./src/app/pages/timetable/timetable.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimetablePage": () => (/* binding */ TimetablePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_timetable_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./timetable.page.html */ 1588);
/* harmony import */ var _timetable_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timetable.page.scss */ 6722);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);




let TimetablePage = class TimetablePage {
    constructor() {
        this.segId = '1';
    }
    ngOnInit() {
    }
    segmentChanged(ev) {
        console.log('Segment changed', ev.detail.value);
        this.segId = ev.detail.value;
    }
};
TimetablePage.ctorParameters = () => [];
TimetablePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-timetable',
        template: _raw_loader_timetable_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_timetable_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TimetablePage);



/***/ }),

/***/ 6722:
/*!*****************************************************!*\
  !*** ./src/app/pages/timetable/timetable.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top ion-label {\n  color: #fff;\n  font-size: 22px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: auto;\n  min-height: calc(100% - 80px);\n}\nion-content .content_div .cardData {\n  padding-left: 20px;\n  padding-top: 20px;\n  margin-bottom: 10px;\n  border: 1px solid #ccc;\n  border-radius: 20px;\n  height: auto;\n}\nion-content .content_div .cardData #subject {\n  color: #2855ae;\n  background-color: #e6efff;\n  padding: 5px;\n  border-radius: 10px;\n}\nion-content .content_div .cardData p span {\n  float: right;\n  margin-right: 20px;\n}\nion-content .content_div ion-segment {\n  margin-bottom: 20px;\n}\nion-content .content_div ion-segment ion-segment-button {\n  --background-checked:#7292cf;\n  --color-checked:#fff;\n  --indicator-color:#7292cf;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpbWV0YWJsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQURRO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFHWjtBQUNJO0VBQ0ksaUJBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7QUFDUjtBQUFRO0VBQ0ksa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0Qsc0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFFWDtBQURZO0VBQ0ksY0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBR2hCO0FBQ2dCO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0FBQ3BCO0FBS1E7RUFDSSxtQkFBQTtBQUhaO0FBSVk7RUFDSSw0QkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7QUFGaEIiLCJmaWxlIjoidGltZXRhYmxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVBvcHBpbnM6d2dodEA0MDA7NjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5pb24tY29udGVudHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM3MjkyY2YsIzI4NTVhZSApO1xyXG4gICAgLnRvcHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo0MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzVweDtcclxuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MjVweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLWJvdHRvbTo1MHB4O1xyXG4gICAgICAgIGhlaWdodDphdXRvO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IGNhbGMoMTAwJSAtIDgwcHgpO1xyXG4gICAgICAgIC5jYXJkRGF0YXtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjIwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOjIwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206MTBweDtcclxuICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkICNjY2M7XHJcbiAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICBoZWlnaHQ6YXV0bztcclxuICAgICAgICAgICAgI3N1YmplY3R7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMjg1NWFlO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmZjtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6NXB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgc3BhbntcclxuICAgICAgICAgICAgICAgICAgICBmbG9hdDpyaWdodDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlvbi1zZWdtZW50e1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOjIwcHg7XHJcbiAgICAgICAgICAgIGlvbi1zZWdtZW50LWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiM3MjkyY2Y7XHJcbiAgICAgICAgICAgICAgICAtLWNvbG9yLWNoZWNrZWQ6I2ZmZjtcclxuICAgICAgICAgICAgICAgIC0taW5kaWNhdG9yLWNvbG9yOiM3MjkyY2Y7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgfVxyXG4gICAgXHJcbn0iXX0= */");

/***/ }),

/***/ 1588:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/timetable/timetable.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div>\n      <ion-buttons slot=\"start\" class=\"menu_btn\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n        <ion-label>Time Table</ion-label>\n      </ion-buttons>\n    </div>\n\n  </div>\n\n  <div class=\"content_div\">\n    <div>\n      <ion-segment scrollable=\"true\" mode=\"ios\"  value=\"1\"  (ionChange)=\"segmentChanged($event)\">\n        <ion-segment-button value=\"1\">\n          <ion-label>MON</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"2\">\n          <ion-label>TUE</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"3\">\n          <ion-label>WED</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"4\">\n          <ion-label>THU</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"5\">\n          <ion-label>FRI</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"6\">\n          <ion-label>SAT</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n\n   \n    <div>\n      <div class=\"cardData\">\n        <span id=\"subject\">Computer Science</span>\n        <p>05:15 AM - 09:00 AM</p><hr style=\"border:1px solid #ccc; margin-right:10px;\">\n        <p>Cherise James <span>Lecture 1</span></p>        \n      </div>   \n      <div class=\"cardData\">\n        <span id=\"subject\">Mathematic</span>\n        <p>09:00 AM - 09:45 AM</p><hr style=\"border:1px solid #ccc; margin-right:10px;\">\n        <p>Cherise James <span>Lecture 2</span></p>        \n      </div> \n      <div class=\"cardData\">\n        <span id=\"subject\">English</span>\n        <p>09:45 AM - 10:30 AM</p><hr style=\"border:1px solid #ccc; margin-right:10px;\">\n        <p>Marta Magana <span>Lecture 3 </span></p>        \n      </div> \n      <div class=\"cardData\">\n        <span id=\"subject\">Lunch Break</span>\n        <p>10:30 AM - 11:00 AM</p><hr style=\"border:1px solid #ccc; margin-right:10px;\">\n      </div> \n      <div class=\"cardData\">\n        <span id=\"subject\">Sceince</span>\n        <p>11:00 AM - 11:45 AM</p><hr style=\"border:1px solid #ccc; margin-right:10px;\">\n        <p>Miss Yamini <span>Lecture 4</span></p>        \n      </div>     \n    </div>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_timetable_timetable_module_ts.js.map