(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_ask-doubt_ask-doubt_module_ts"],{

/***/ 9865:
/*!*************************************************************!*\
  !*** ./src/app/pages/ask-doubt/ask-doubt-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AskDoubtPageRoutingModule": () => (/* binding */ AskDoubtPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _ask_doubt_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ask-doubt.page */ 9077);




const routes = [
    {
        path: '',
        component: _ask_doubt_page__WEBPACK_IMPORTED_MODULE_0__.AskDoubtPage
    }
];
let AskDoubtPageRoutingModule = class AskDoubtPageRoutingModule {
};
AskDoubtPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AskDoubtPageRoutingModule);



/***/ }),

/***/ 5257:
/*!*****************************************************!*\
  !*** ./src/app/pages/ask-doubt/ask-doubt.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AskDoubtPageModule": () => (/* binding */ AskDoubtPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _ask_doubt_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ask-doubt-routing.module */ 9865);
/* harmony import */ var _ask_doubt_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ask-doubt.page */ 9077);







let AskDoubtPageModule = class AskDoubtPageModule {
};
AskDoubtPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ask_doubt_routing_module__WEBPACK_IMPORTED_MODULE_0__.AskDoubtPageRoutingModule
        ],
        declarations: [_ask_doubt_page__WEBPACK_IMPORTED_MODULE_1__.AskDoubtPage]
    })
], AskDoubtPageModule);



/***/ }),

/***/ 9077:
/*!***************************************************!*\
  !*** ./src/app/pages/ask-doubt/ask-doubt.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AskDoubtPage": () => (/* binding */ AskDoubtPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_ask_doubt_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./ask-doubt.page.html */ 4820);
/* harmony import */ var _ask_doubt_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ask-doubt.page.scss */ 598);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);




let AskDoubtPage = class AskDoubtPage {
    constructor() { }
    ngOnInit() {
    }
};
AskDoubtPage.ctorParameters = () => [];
AskDoubtPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-ask-doubt',
        template: _raw_loader_ask_doubt_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_ask_doubt_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AskDoubtPage);



/***/ }),

/***/ 598:
/*!*****************************************************!*\
  !*** ./src/app/pages/ask-doubt/ask-doubt.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .menu_btn ion-label {\n  color: #fff;\n  font-size: 24px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: auto;\n  min-height: calc(100% - 70px);\n}\nion-content .content_div ion-button {\n  --background:linear-gradient(#7292cf,#2855ae );\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzay1kb3VidC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQUFXO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFFZjtBQUtJO0VBQ0ksaUJBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7QUFIUjtBQUlRO0VBQ1EsOENBQUE7QUFGaEIiLCJmaWxlIjoiYXNrLWRvdWJ0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVBvcHBpbnM6d2dodEA0MDA7NjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5pb24tY29udGVudHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM3MjkyY2YsIzI4NTVhZSApO1xyXG4gICAgLnRvcHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo0MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAubWVudV9idG57XHJcbiAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgfVxyXG5cclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgLmNvbnRlbnRfZGl2e1xyXG4gICAgICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzVweDtcclxuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MjVweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBwYWRkaW5nLWJvdHRvbTo1MHB4O1xyXG4gICAgICAgIGhlaWdodDphdXRvO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IGNhbGMoMTAwJSAtIDcwcHgpO1xyXG4gICAgICAgIGlvbi1idXR0b257ICAgXHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM3MjkyY2YsIzI4NTVhZSApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ== */");

/***/ }),

/***/ 4820:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ask-doubt/ask-doubt.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div>\n      <ion-buttons slot=\"start\" class=\"menu_btn\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n        <ion-label>Ask Doubt</ion-label>\n    </ion-buttons>\n    </div>\n    \n  </div>\n\n  <div class=\"content_div\">\n    <form>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=12>\n            <ion-item>\n              <ion-label position=\"floating\">Select Teacher</ion-label>\n              <ion-select placeholder=\"Select One\">\n                <ion-select-option value=\"f\">Alexa Clark</ion-select-option>\n                <ion-select-option value=\"m\">John Doe</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n\n          <ion-col size=12>\n            <ion-item>\n              <ion-label position=\"floating\">Select Subject</ion-label>\n              <ion-select placeholder=\"Select One\">\n                <ion-select-option value=\"f\">Angular</ion-select-option>\n                <ion-select-option value=\"m\">React</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n\n          <ion-col size=12>\n            <ion-item>\n              <ion-label position=\"floating\">Title</ion-label>\n              <ion-input></ion-input>\n            </ion-item>\n          </ion-col>\n\n          <ion-col size=12>\n            <ion-item>\n              <ion-label position=\"floating\">Doubt Description</ion-label>\n              <ion-textarea></ion-textarea>\n            </ion-item>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid><br>\n     \n        <ion-button expand=\"full\">Send</ion-button>\n      \n    </form>\n\n  </div>\n  \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_ask-doubt_ask-doubt_module_ts.js.map