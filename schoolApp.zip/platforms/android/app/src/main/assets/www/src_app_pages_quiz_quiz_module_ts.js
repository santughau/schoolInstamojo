(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_quiz_quiz_module_ts"],{

/***/ 358:
/*!***************************************************!*\
  !*** ./src/app/pages/quiz/quiz-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuizPageRoutingModule": () => (/* binding */ QuizPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _quiz_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quiz.page */ 1685);




const routes = [
    {
        path: '',
        component: _quiz_page__WEBPACK_IMPORTED_MODULE_0__.QuizPage
    }
];
let QuizPageRoutingModule = class QuizPageRoutingModule {
};
QuizPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], QuizPageRoutingModule);



/***/ }),

/***/ 2921:
/*!*******************************************!*\
  !*** ./src/app/pages/quiz/quiz.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuizPageModule": () => (/* binding */ QuizPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _quiz_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quiz-routing.module */ 358);
/* harmony import */ var _quiz_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./quiz.page */ 1685);







let QuizPageModule = class QuizPageModule {
};
QuizPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _quiz_routing_module__WEBPACK_IMPORTED_MODULE_0__.QuizPageRoutingModule
        ],
        declarations: [_quiz_page__WEBPACK_IMPORTED_MODULE_1__.QuizPage]
    })
], QuizPageModule);



/***/ }),

/***/ 1685:
/*!*****************************************!*\
  !*** ./src/app/pages/quiz/quiz.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuizPage": () => (/* binding */ QuizPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_quiz_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./quiz.page.html */ 902);
/* harmony import */ var _quiz_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./quiz.page.scss */ 5222);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var src_app_service_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/service/app-service.service */ 6466);







let QuizPage = class QuizPage {
    constructor(service, loadingController, router, _route) {
        this.service = service;
        this.loadingController = loadingController;
        this.router = router;
        this._route = _route;
        this.show = true;
        this.btnDissabled = true;
        this.questions = [];
        this.district = [];
        this.taluka = [];
        this.userAnswer = "";
        this.question_count = 0;
        this.buttonTitle = 'Next';
        this.correctAnswer = 0;
        this.dt = new Date(new Date().setTime(0));
        this.ctime = this.dt.getTime();
        this.seconds = Math.floor((this.ctime % (1000 * 60)) / 1000);
        this.minutes = Math.floor((this.ctime % (1000 * 60 * 60)) / (1000 * 60));
        this.time = 0;
        this.formatted_sec = "00";
        this.formatted_min = "00";
        this.distId = 0;
        this.result = {
            fullName: '',
            mobile: '',
            dist: '',
            tal: ''
        };
        this.uid = "";
        this.registerData = {
            profile_fullname: "",
            profile_mobile: "",
            profile_email: "",
            profile_distId: "",
            profile_taluka: "",
            profile_password: "",
            profile_uid: "",
            profile_id: ""
        };
        this.saveData = {};
        this.skleton = false;
    }
    ngOnInit() {
        this.userAnswer = "";
        this.question_count = 0;
        this.correctAnswer = 0;
        this.formatted_min = "00";
        this.formatted_sec = "00";
        this.time = 0;
        this.questions = [];
        this.district = [];
        this.taluka = [];
        this.distId = 0;
        this.examId = +this._route.snapshot.params['id'];
        this.service.getQuestionList(this.examId).subscribe((res) => {
            this.questions = res.document.records;
            console.log(this.questions);
            this.skleton = true;
        });
        this.timer();
    }
    goBack() {
        this.router.navigate(['/home']);
    }
    timer() {
        this.stopTimer = setInterval(() => {
            this.time++;
            if (this.seconds < 59) {
                this.seconds++;
            }
            else {
                this.seconds = 0;
                this.minutes++;
            }
            this.formatted_sec = this.seconds < 10 ? `0${this.seconds}` : `${this.seconds}`;
            this.formatted_min = this.minutes < 10 ? `0${this.minutes}` : `${this.minutes}`;
        }, 1000);
    }
    toggleClass(item) {
        this.btnDissabled = false;
        if (item == 0) {
            this.userAnswer = "A";
        }
        else if (item == 1) {
            this.userAnswer = "B";
        }
        else if (item == 2) {
            this.userAnswer = "C";
        }
        else if (item == 3) {
            this.userAnswer = "D";
        }
        else {
        }
        if (this.userAnswer == this.questions[this.question_count].answer) {
            this.correctAnswer++;
            let options = document.querySelectorAll("div.option");
            let indicator = document.querySelectorAll(".answers-indicator div");
            for (let i = 0; i < options.length; i++) {
                options[i].classList.remove("correct");
                options[i].classList.add("already-answered");
            }
            options[item].classList.add("correct");
            indicator[this.question_count].classList.add("correct");
        }
        else {
            let options = document.querySelectorAll("div.option");
            let indicator = document.querySelectorAll(".answers-indicator div");
            for (let i = 0; i < options.length; i++) {
                options[i].classList.remove("wrong");
                options[i].classList.add("already-answered");
            }
            options[item].classList.add("wrong");
            indicator[this.question_count].classList.add("wrong");
            if (this.questions[this.question_count].answer == 'A') {
                setTimeout(() => {
                    options[0].classList.add("correct");
                }, 2000);
            }
            if (this.questions[this.question_count].answer == 'B') {
                setTimeout(() => {
                    options[1].classList.add("correct");
                }, 2000);
            }
            if (this.questions[this.question_count].answer == 'C') {
                setTimeout(() => {
                    options[2].classList.add("correct");
                }, 2000);
            }
            if (this.questions[this.question_count].answer == 'D') {
                setTimeout(() => {
                    options[3].classList.add("correct");
                }, 2000);
            }
        }
    }
    presentLoading() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please Wait .... ',
            });
            yield loading.present();
        });
    }
    next() {
        this.btnDissabled = true;
        if (this.question_count == this.questions.length - 1) {
            this.show = false;
            this.onSave();
            this.question_count--;
        }
        if (this.question_count == this.questions.length - 2) {
            this.buttonTitle = "Finish";
            clearInterval(this.stopTimer);
        }
        this.question_count++;
    }
    onSave() {
        this.saveData = {
            leaderBoard_profileId: this.registerData.profile_id,
            leaderboard_mobile: this.registerData.profile_mobile,
            leaderBoard_exam_id: this.examId,
            leaderboard_time: this.formatted_min + ':' + this.formatted_sec,
            leaderBoard_marks: (100 * this.correctAnswer / this.questions.length).toFixed(2)
        };
    }
};
QuizPage.ctorParameters = () => [
    { type: src_app_service_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute }
];
QuizPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-quiz',
        template: _raw_loader_quiz_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_quiz_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], QuizPage);



/***/ }),

/***/ 5222:
/*!*******************************************!*\
  !*** ./src/app/pages/quiz/quiz.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .question-number {\n  color: #fff;\n  padding-left: 20px;\n  padding-right: 20px;\n  margin-top: 10px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding-bottom: 50px;\n  min-height: calc(100% - 80px);\n  height: auto;\n}\nion-content .content_div .custom-box {\n  max-width: 100%;\n  background-color: #ffffff;\n  margin: 2px auto;\n  padding: 0px 10px;\n  border-radius: 10px;\n  animation: fadeInRight 1s ease;\n}\n@keyframes fadeInRight {\n  0% {\n    transform: translateX(40px);\n    opacity: 0;\n  }\n  100% {\n    transform: translateX(0px);\n    opacity: 1;\n  }\n}\nion-content .content_div .custom-box::before,\nion-content .content_div .custom-box::after {\n  content: \"\";\n  clear: both;\n  display: table;\n}\nion-content .content_div .custom-box.hide {\n  display: none;\n}\nion-content .content_div .home-box h3 {\n  font-size: 18px;\n  color: #000000;\n  font-weight: 500;\n  margin-bottom: 15px;\n  line-height: 25px;\n}\nion-content .content_div .home-box p {\n  font-size: 16px;\n  margin-bottom: 10px;\n  line-height: 22px;\n  color: #000000;\n  font-weight: 400;\n}\nion-content .content_div .home-box p span {\n  font-weight: 500;\n}\nion-content .content_div .home-box .btn {\n  margin-top: 20px;\n}\nion-content .content_div .btn {\n  padding: 15px 45px;\n  background-color: #dc3545;\n  color: #ffffff;\n  border: none;\n  border-radius: 5px;\n  font-size: 15px;\n  cursor: pointer;\n  display: inline-block;\n}\nion-content .content_div .quiz-box .question-number,\nion-content .content_div .quiz-box .question-text,\nion-content .content_div .quiz-box .option-container,\nion-content .content_div .quiz-box .answers-indicator,\nion-content .content_div .quiz-box .next-question-btn {\n  width: 100%;\n  float: left;\n}\nion-content .content_div .quiz-box .question-number {\n  font-size: 18px;\n  color: #dc3545;\n  font-weight: 600;\n  border-bottom: 1px solid #cccccc;\n  padding-bottom: 10px;\n  line-height: 25px;\n}\nion-content .content_div .quiz-box .question-text {\n  font-size: 22px;\n  color: #000000;\n  line-height: 28px;\n  font-weight: 400;\n  padding: 20px 0px;\n  margin: 0px;\n}\nion-content .content_div delAni {\n  animation-delay: 2s;\n}\nion-content .content_div .quiz-box .option-container .option {\n  background-color: #cccccc;\n  padding: 13px 15px;\n  font-size: 16px;\n  line-height: 22px;\n  color: black;\n  border-radius: 5px;\n  margin-bottom: 10px;\n  cursor: pointer;\n  text-transform: capitalize;\n  opacity: 0;\n  animation: fadeIn 0.3s ease forwards;\n  position: relative;\n  overflow: hidden;\n}\nion-content .content_div .quiz-box .option-container .option.already-answered {\n  pointer-events: none;\n}\nion-content .content_div .quiz-box .option-container .option.correct::before {\n  content: \"\";\n  position: absolute;\n  left: 0px;\n  top: 0px;\n  height: 100%;\n  width: 100%;\n  background-color: green;\n  color: white;\n  z-index: -1;\n  animation: slideInLeft 2s ease forwards;\n}\n@keyframes slideInLeft {\n  0% {\n    transform: translateX(-100%);\n  }\n  100% {\n    transform: translateX(0%);\n  }\n}\nion-content .content_div .quiz-box .option-container .option.wrong::before {\n  content: \"\";\n  position: absolute;\n  left: 0px;\n  top: 0px;\n  height: 100%;\n  width: 100%;\n  background-color: red;\n  color: white;\n  z-index: -1;\n  animation: slideInLeft 2s ease forwards;\n}\nion-content .content_div .quiz-box .option-container .option.correct {\n  color: #ffffff;\n}\nion-content .content_div .quiz-box .option-container .option.wrong {\n  color: #ffffff;\n}\n@keyframes fadeIn {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\nion-content .content_div .quiz-box .btn {\n  margin: 15px 0px;\n}\nion-content .content_div .quiz-box .answers-indicator {\n  border-top: 1px solid #cccccc;\n}\nion-content .content_div .quiz-box .answers-indicator div {\n  height: 40px;\n  width: 40px;\n  display: inline-block;\n  background-color: #cccccc;\n  border-radius: 50%;\n  margin-right: 3px;\n  margin-top: 15px;\n}\nion-content .content_div .quiz-box .answers-indicator div.correct {\n  background-color: green;\n}\nion-content .content_div .quiz-box .answers-indicator div.wrong {\n  background-color: red;\n}\nion-content .content_div .result-box {\n  text-align: center;\n}\nion-content .content_div .result-box .hide {\n  display: none;\n}\nion-content .content_div .result-box h1 {\n  font-size: 36px;\n  line-height: 42px;\n  color: #dc3545;\n}\nion-content .content_div .result-box table {\n  width: 100%;\n  border-collapse: collapse;\n  margin: 30px 0;\n}\nion-content .content_div .result-box table td {\n  border: 1px solid #cccccc;\n  padding: 8px 15px;\n  font-weight: 500;\n  color: #000000;\n  width: 50%;\n  text-align: left;\n  font-size: 18px;\n}\nion-content .content_div .result-box .btn {\n  margin-right: 20px;\n}\n.bk {\n  padding-left: 10px;\n  padding-right: 10px;\n  font-size: 16px;\n}\n* {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInF1aXoucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHlGQUFBO0FBQ1I7RUFDSSxrQ0FBQTtFQUNBLDhDQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFEUTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUdaO0FBRlk7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBSWhCO0FBSUk7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRlI7QUFJSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFGUjtBQUdRO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFEWjtBQUlVO0VBQ0U7SUFDRSwyQkFBQTtJQUNBLFVBQUE7RUFGWjtFQUlVO0lBQ0UsMEJBQUE7SUFDQSxVQUFBO0VBRlo7QUFDRjtBQUtVOztFQUVFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQUhaO0FBS1U7RUFDRSxhQUFBO0FBSFo7QUFNVTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBSlo7QUFPVTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBTFo7QUFPVTtFQUNFLGdCQUFBO0FBTFo7QUFPVTtFQUNFLGdCQUFBO0FBTFo7QUFPVTtFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtBQUxaO0FBUVU7Ozs7O0VBS0UsV0FBQTtFQUNBLFdBQUE7QUFOWjtBQVFVO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQU5aO0FBUVU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7QUFOWjtBQVdVO0VBQ0UsbUJBQUE7QUFUWjtBQWFVO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0VBQ0EsVUFBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQVhaO0FBY1U7RUFDRSxvQkFBQTtBQVpaO0FBZVU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHVDQUFBO0FBYlo7QUFlVTtFQUNFO0lBQ0UsNEJBQUE7RUFiWjtFQWVVO0lBQ0UseUJBQUE7RUFiWjtBQUNGO0FBZ0JVO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSx1Q0FBQTtBQWRaO0FBaUJVO0VBQ0UsY0FBQTtBQWZaO0FBaUJVO0VBQ0UsY0FBQTtBQWZaO0FBa0JVO0VBQ0U7SUFDRSxVQUFBO0VBaEJaO0VBa0JVO0lBQ0UsVUFBQTtFQWhCWjtBQUNGO0FBbUJVO0VBQ0UsZ0JBQUE7QUFqQlo7QUFtQlU7RUFDRSw2QkFBQTtBQWpCWjtBQW1CVTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQWpCWjtBQW9CVTtFQUNFLHVCQUFBO0FBbEJaO0FBcUJVO0VBQ0UscUJBQUE7QUFuQlo7QUFzQlU7RUFDRSxrQkFBQTtBQXBCWjtBQXVCVTtFQUNFLGFBQUE7QUFyQlo7QUF1QlU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBckJaO0FBdUJVO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtBQXJCWjtBQXVCVTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBckJaO0FBd0JVO0VBQ0Usa0JBQUE7QUF0Qlo7QUE2QkE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0MsZUFBQTtBQTFCTDtBQThCRztFQUNDLHNCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0FBM0JKIiwiZmlsZSI6InF1aXoucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UG9wcGluczp3Z2h0QDQwMDs2MDAmZGlzcGxheT1zd2FwJyk7XHJcbmlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAudG9we1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tdG9wOjQwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICAgICAgICAuYmFja19kaXZ7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6MjVweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICAucXVlc3Rpb24tbnVtYmVye1xyXG4gICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OjIwcHg7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDoyMHB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MTBweDtcclxuICAgIH1cclxuICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOjI1cHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MzBweDsgICAgICAgXHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206NTBweDtcclxuICAgICAgICBtaW4taGVpZ2h0OiBjYWxjKDEwMCUgLSA4MHB4KTtcclxuICAgICAgICBoZWlnaHQ6YXV0bztcclxuICAgICAgICAuY3VzdG9tLWJveCB7XHJcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxuICAgICAgICAgICAgbWFyZ2luOiAycHggYXV0bztcclxuICAgICAgICAgICAgcGFkZGluZzogMHB4IDEwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbjogZmFkZUluUmlnaHQgMXMgZWFzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgQGtleWZyYW1lcyBmYWRlSW5SaWdodCB7XHJcbiAgICAgICAgICAgIDAlIHtcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoNDBweCk7XHJcbiAgICAgICAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAxMDAlIHtcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMHB4KTtcclxuICAgICAgICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jdXN0b20tYm94OjpiZWZvcmUsXHJcbiAgICAgICAgICAuY3VzdG9tLWJveDo6YWZ0ZXIge1xyXG4gICAgICAgICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgICAgICBjbGVhcjogYm90aDtcclxuICAgICAgICAgICAgZGlzcGxheTogdGFibGU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuY3VzdG9tLWJveC5oaWRlIHtcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmhvbWUtYm94IGgzIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDI1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5ob21lLWJveCBwIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMjJweDtcclxuICAgICAgICAgICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuaG9tZS1ib3ggcCBzcGFuIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5ob21lLWJveCAuYnRuIHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5idG4ge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxNXB4IDQ1cHg7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNkYzM1NDU7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnF1aXotYm94IC5xdWVzdGlvbi1udW1iZXIsXHJcbiAgICAgICAgICAucXVpei1ib3ggLnF1ZXN0aW9uLXRleHQsXHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIsXHJcbiAgICAgICAgICAucXVpei1ib3ggLmFuc3dlcnMtaW5kaWNhdG9yLFxyXG4gICAgICAgICAgLnF1aXotYm94IC5uZXh0LXF1ZXN0aW9uLWJ0biB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5xdWl6LWJveCAucXVlc3Rpb24tbnVtYmVyIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogI2RjMzU0NTtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjY2NjY2M7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMjVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5xdWl6LWJveCAucXVlc3Rpb24tdGV4dCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICAgICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAyMHB4IDBweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIge1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBkZWxBbml7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMnM7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIgLm9wdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNjY2NjY2M7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEzcHggMTVweDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMjJweDtcclxuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbjogZmFkZUluIDAuM3MgZWFzZSBmb3J3YXJkcztcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIgLm9wdGlvbi5hbHJlYWR5LWFuc3dlcmVkIHtcclxuICAgICAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5xdWl6LWJveCAub3B0aW9uLWNvbnRhaW5lciAub3B0aW9uLmNvcnJlY3Q6OmJlZm9yZSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgbGVmdDogMHB4O1xyXG4gICAgICAgICAgICB0b3A6IDBweDtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XHJcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgei1pbmRleDogLTE7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbjogc2xpZGVJbkxlZnQgMnMgZWFzZSBmb3J3YXJkcztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIEBrZXlmcmFtZXMgc2xpZGVJbkxlZnQge1xyXG4gICAgICAgICAgICAwJSB7XHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDAlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAxMDAlIHtcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5xdWl6LWJveCAub3B0aW9uLWNvbnRhaW5lciAub3B0aW9uLndyb25nOjpiZWZvcmUge1xyXG4gICAgICAgICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGxlZnQ6IDBweDtcclxuICAgICAgICAgICAgdG9wOiAwcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICB6LWluZGV4OiAtMTtcclxuICAgICAgICAgICAgYW5pbWF0aW9uOiBzbGlkZUluTGVmdCAycyBlYXNlIGZvcndhcmRzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIgLm9wdGlvbi5jb3JyZWN0IHtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAucXVpei1ib3ggLm9wdGlvbi1jb250YWluZXIgLm9wdGlvbi53cm9uZyB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBAa2V5ZnJhbWVzIGZhZGVJbiB7XHJcbiAgICAgICAgICAgIDAlIHtcclxuICAgICAgICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDEwMCUge1xyXG4gICAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnF1aXotYm94IC5idG4ge1xyXG4gICAgICAgICAgICBtYXJnaW46IDE1cHggMHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLnF1aXotYm94IC5hbnN3ZXJzLWluZGljYXRvciB7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjY2NjY2NjO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLnF1aXotYm94IC5hbnN3ZXJzLWluZGljYXRvciBkaXYge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNjY2NjY2M7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAzcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5xdWl6LWJveCAuYW5zd2Vycy1pbmRpY2F0b3IgZGl2LmNvcnJlY3Qge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnF1aXotYm94IC5hbnN3ZXJzLWluZGljYXRvciBkaXYud3Jvbmcge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQ7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLnJlc3VsdC1ib3gge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5yZXN1bHQtYm94IC5oaWRlIHtcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5yZXN1bHQtYm94IGgxIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzNnB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogNDJweDtcclxuICAgICAgICAgICAgY29sb3I6ICNkYzM1NDU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAucmVzdWx0LWJveCB0YWJsZSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICAgICAgICBtYXJnaW46IDMwcHggMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5yZXN1bHQtYm94IHRhYmxlIHRkIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjY2NjYztcclxuICAgICAgICAgICAgcGFkZGluZzogOHB4IDE1cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5yZXN1bHQtYm94IC5idG4ge1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICBcclxufVxyXG4gICAgXHJcbn1cclxuXHJcbi5iayB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG4gICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAvL2JhY2tncm91bmQtY29sb3I6ICNFQjQ0NUEgIWltcG9ydGFudDtcclxuICAgfVxyXG5cclxuICAgKiB7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgfSJdfQ== */");

/***/ }),

/***/ 902:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/quiz/quiz.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Questions</ion-label>\n    </div>\n   \n  \n  </div>\n  <div class=\"question-number\">Question : {{question_count+1}} / {{questions.length}} <span\n    style=\"float: right;\">{{formatted_min}}:{{formatted_sec}}</span></div>\n  <div class=\"content_div\">\n    <div class=\"row \" *ngIf=\"skleton\">\n      <div class=\"col-md-12 bk\">\n        <div class=\"quiz-box custom-box\" *ngIf=\"show\">\n          <div style=\"text-align: justify;\" class=\"question-text text-danger\"\n            [innerHtml]=\"questions[question_count]?.question\"></div>\n          <div class=\"option-container\">\n  \n            <div style=\"text-align: justify;\" id=\"0\" class=\"option \"\n              *ngFor=\"let item of questions[question_count]?.options; let i = index\" [style.animation-delay.s]=\"i\"\n              (click)=\"toggleClass(i)\" [innerHtml]=\"item\"></div>\n          </div>\n          <div class=\"next-question-btn\">\n            <button [disabled]=\"btnDissabled\" class=\"btn\" type=\"button\" (click)=\"next()\">{{buttonTitle}}</button>\n          </div>\n          <div class=\"answers-indicator\">\n            <div *ngFor=\"let item of questions; let i = index\"></div>\n          </div>\n        </div>\n        <div class=\"result-box custom-box\" *ngIf=\"!show\" style=\"height: 100vh;\">\n          <h1>Result</h1>\n          <form #resultForm=\"ngForm\">\n            <table>\n              <tr>\n                <td class=\"bg-dark text-white\">Total Questions</td>\n                <td class=\"total-questions\">{{questions.length}}</td>\n              </tr>\n  \n              <tr>\n                <td class=\"bg-dark text-white\">Correct Answers</td>\n                <td class=\"total-correct\">{{correctAnswer}}</td>\n              </tr>\n              <tr>\n                <td class=\"bg-dark text-white\">Wrong Answers</td>\n                <td class=\"total-wrong\">{{questions.length - correctAnswer}}</td>\n              </tr>\n              <tr>\n                <td class=\"bg-dark text-white\">Percentages</td>\n                <td class=\"percentage\">{{100 * correctAnswer /questions.length | number : '1.2-2'}}%</td>\n              </tr>\n              <tr>\n                <td class=\"bg-dark text-white\">Time  </td>\n                <td class=\"percentage\">{{formatted_min}} : {{formatted_sec}}</td>\n              </tr>\n            </table>         \n          </form>\n        </div>\n      </div>\n  \n    </div>\n  \n  \n  </div>\n  \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_quiz_quiz_module_ts.js.map