(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_event-list_event-list_module_ts"],{

/***/ 5335:
/*!***************************************************************!*\
  !*** ./src/app/pages/event-list/event-list-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventListPageRoutingModule": () => (/* binding */ EventListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _event_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./event-list.page */ 6909);




const routes = [
    {
        path: '',
        component: _event_list_page__WEBPACK_IMPORTED_MODULE_0__.EventListPage
    }
];
let EventListPageRoutingModule = class EventListPageRoutingModule {
};
EventListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EventListPageRoutingModule);



/***/ }),

/***/ 8493:
/*!*******************************************************!*\
  !*** ./src/app/pages/event-list/event-list.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventListPageModule": () => (/* binding */ EventListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _event_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./event-list-routing.module */ 5335);
/* harmony import */ var _event_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-list.page */ 6909);







let EventListPageModule = class EventListPageModule {
};
EventListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _event_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.EventListPageRoutingModule
        ],
        declarations: [_event_list_page__WEBPACK_IMPORTED_MODULE_1__.EventListPage]
    })
], EventListPageModule);



/***/ }),

/***/ 6909:
/*!*****************************************************!*\
  !*** ./src/app/pages/event-list/event-list.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventListPage": () => (/* binding */ EventListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_event_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./event-list.page.html */ 7755);
/* harmony import */ var _event_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-list.page.scss */ 9412);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let EventListPage = class EventListPage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    goBack() {
        this._router.navigate(['/home']);
    }
};
EventListPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
EventListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-event-list',
        template: _raw_loader_event_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_event_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EventListPage);



/***/ }),

/***/ 9412:
/*!*******************************************************!*\
  !*** ./src/app/pages/event-list/event-list.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: auto;\n  min-height: calc(100% - 80px);\n}\nion-content .content_div .cardData {\n  padding-left: 20px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n  margin-bottom: 10px;\n  border: 1px solid #ccc;\n  border-radius: 20px;\n  height: auto;\n}\nion-content .content_div .cardData #subject {\n  color: #2855ae;\n  background-color: #e6efff;\n  padding: 5px;\n  border-radius: 10px;\n}\nion-content .content_div .cardData .box {\n  display: grid;\n  grid-template-columns: 25% 75%;\n  padding-left: 10px;\n  padding-top: 10px;\n  justify-items: center;\n  grid-gap: 10px;\n}\nion-content .content_div .cardData .thumbnail img {\n  width: 100%;\n  border-radius: 10px;\n  height: same-as-width;\n  background-size: cover;\n}\nion-content .content_div .cardData .description {\n  justify-self: start;\n}\nion-content .content_div .cardData .description span {\n  color: blue;\n}\nion-content .content_div .cardData .description .paragraph {\n  text-align: justify;\n  margin-right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV2ZW50LWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHlGQUFBO0FBQ1I7RUFDSSxrQ0FBQTtFQUNBLDhDQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFEUTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUdaO0FBQ1k7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBQ2hCO0FBT0k7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtBQUxSO0FBTVE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtFQUVELHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBTFg7QUFNWTtFQUNJLGNBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQUpoQjtBQU1ZO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsY0FBQTtBQUpoQjtBQU9nQjtFQUNJLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7QUFMcEI7QUFRVztFQUNDLG1CQUFBO0FBTlo7QUFPWTtFQUNJLFdBQUE7QUFMaEI7QUFPWTtFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUFMaEIiLCJmaWxlIjoiZXZlbnQtbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Qb3BwaW5zOndnaHRANDAwOzYwMCZkaXNwbGF5PXN3YXAnKTtcclxuaW9uLWNvbnRlbnR7XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgLS1iYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgjNzI5MmNmLCMyODU1YWUgKTtcclxuICAgIC50b3B7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgIG1hcmdpbi10b3A6NDBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgIC5iYWNrX2RpdntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjI1cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZTtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjMwcHg7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOjUwcHg7XHJcbiAgICAgICAgaGVpZ2h0OmF1dG87XHJcbiAgICAgICAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gODBweCk7XHJcbiAgICAgICAgLmNhcmREYXRhe1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6MjBweDtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206MjBweDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbToxMHB4O1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkICNjY2M7XHJcbiAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICBoZWlnaHQ6YXV0bztcclxuICAgICAgICAgICAgI3N1YmplY3R7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojMjg1NWFlO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmZjtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6NXB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5ib3h7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgICAgICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAyNSUgNzUlO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OjEwcHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDoxMHB4O1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgZ3JpZC1nYXA6MTBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudGh1bWJuYWlse1xyXG4gICAgICAgICAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IHNhbWUtYXMtd2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIC5kZXNjcmlwdGlvbntcclxuICAgICAgICAgICAganVzdGlmeS1zZWxmOnN0YXJ0O1xyXG4gICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgY29sb3I6Ymx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAucGFyYWdyYXBoe1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICB9XHJcbiAgICBcclxufSJdfQ== */");

/***/ }),

/***/ 7755:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/event-list/event-list.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Events & Programs</ion-label>\n    </div>\n  </div>\n\n  <div class=\"content_div\">\n    <div>\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1010.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n\n      <div class=\"cardData\">\n        <span id=\"subject\">Fishing Tournament</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n             <img src=\"../../../assets/1011.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1017.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1013.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1014.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1015.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cardData\">\n        <span id=\"subject\">SleepOver Night</span>\n        <div class='box'>\n          <div class=\"thumbnail\">\n            <img src=\"../../../assets/1004.jfif\" />\n          </div>\n          <div class=\"description\">\n            <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n            <p class=\"paragraph\">A sleepover is a great treat for kids. \n              Many schools use such an event as the. </p>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_event-list_event-list_module_ts.js.map