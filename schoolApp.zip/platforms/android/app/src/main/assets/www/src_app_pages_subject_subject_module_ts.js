(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_subject_subject_module_ts"],{

/***/ 8164:
/*!*********************************************************!*\
  !*** ./src/app/pages/subject/subject-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectPageRoutingModule": () => (/* binding */ SubjectPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _subject_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject.page */ 6586);




const routes = [
    {
        path: '',
        component: _subject_page__WEBPACK_IMPORTED_MODULE_0__.SubjectPage
    }
];
let SubjectPageRoutingModule = class SubjectPageRoutingModule {
};
SubjectPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SubjectPageRoutingModule);



/***/ }),

/***/ 2874:
/*!*************************************************!*\
  !*** ./src/app/pages/subject/subject.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectPageModule": () => (/* binding */ SubjectPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _subject_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject-routing.module */ 8164);
/* harmony import */ var _subject_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject.page */ 6586);







let SubjectPageModule = class SubjectPageModule {
};
SubjectPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject_routing_module__WEBPACK_IMPORTED_MODULE_0__.SubjectPageRoutingModule
        ],
        declarations: [_subject_page__WEBPACK_IMPORTED_MODULE_1__.SubjectPage]
    })
], SubjectPageModule);



/***/ }),

/***/ 6586:
/*!***********************************************!*\
  !*** ./src/app/pages/subject/subject.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectPage": () => (/* binding */ SubjectPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_subject_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject.page.html */ 1034);
/* harmony import */ var _subject_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject.page.scss */ 6373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let SubjectPage = class SubjectPage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
        this.subjects = [
            {
                img: 'assets/english.png',
                name: 'English'
            },
            {
                img: 'assets/chemistry.png',
                name: 'Chemistry'
            },
            {
                img: 'assets/statistics.png',
                name: 'Statistics'
            },
            {
                img: 'assets/maths.png',
                name: 'Mathamatics'
            },
            {
                img: 'assets/physics.png',
                name: 'Physics'
            },
            {
                img: 'assets/social.png',
                name: 'Social Science'
            },
        ];
    }
    goToSubject(id) {
        console.log(id);
        this._router.navigate(['/chapter-list']);
    }
    goBack() {
        this._router.navigate(['/home']);
    }
};
SubjectPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
SubjectPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-subject',
        template: _raw_loader_subject_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SubjectPage);



/***/ }),

/***/ 6373:
/*!*************************************************!*\
  !*** ./src/app/pages/subject/subject.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding-bottom: 50px;\n  padding-left: 20px;\n  padding-right: 20px;\n  min-height: calc(100% - 80px);\n  height: auto;\n}\nion-content .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  display: block;\n  text-align: center;\n  margin-top: 10px;\n  color: red;\n}\nion-content .content_div ion-grid {\n  padding: 0px;\n  width: 100%;\n}\nion-content .content_div .col_div {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\nion-content .content_div .col_div img {\n  width: 70px;\n}\nion-content .content_div .col_div ion-label {\n  color: var(--ion-color-primary);\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHlGQUFBO0FBQ1I7RUFDSSxrQ0FBQTtFQUNBLDhDQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFEUTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUdaO0FBRlk7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBSWhCO0FBR0k7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtBQURSO0FBRVE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Qsa0JBQUE7RUFDQyxnQkFBQTtFQUNBLFVBQUE7QUFBWjtBQUdRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7QUFEWjtBQUdRO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7QUFEWjtBQUdZO0VBQ0ksV0FBQTtBQURoQjtBQUlZO0VBQ0ksK0JBQUE7RUFDQSxlQUFBO0FBRmhCIiwiZmlsZSI6InN1YmplY3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UG9wcGluczp3Z2h0QDQwMDs2MDAmZGlzcGxheT1zd2FwJyk7XHJcbmlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAudG9we1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tdG9wOjQwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICAgICAgICAuYmFja19kaXZ7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6MjVweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOjI1cHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MzBweDsgICAgICAgXHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206NTBweDtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gODBweCk7XHJcbiAgICAgICAgaGVpZ2h0OmF1dG87XHJcbiAgICAgICAgLmhlbGxvX2xibHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOjE4cHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICAgICAgY29sb3I6cmVkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW9uLWdyaWR7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6MHB4O1xyXG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuY29sX2RpdntcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgaGVpZ2h0OjE1MHB4O1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHJcbiAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgIHdpZHRoOjcwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6NXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG59XHJcbiAgICBcclxufSJdfQ== */");

/***/ }),

/***/ 1034:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/subject/subject.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Quiz</ion-label>\n    </div>\n   \n  </div>\n\n  <div class=\"content_div\"> \n\n      <ion-label class=\"hello_lbl\">Hello , Please Choose Your Subject</ion-label>\n\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"6\" (click)=\"goToSubject(1)\" *ngFor=\"let item of subjects \">\n            <div class=\"col_div\">\n              <img src=\"{{item.img}}\" >\n              <ion-label>{{item.name}}</ion-label>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n  \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_subject_subject_module_ts.js.map