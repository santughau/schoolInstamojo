(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_details-page_details-page_module_ts"],{

/***/ 3466:
/*!*******************************************************************!*\
  !*** ./src/app/pages/details-page/details-page-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailsPagePageRoutingModule": () => (/* binding */ DetailsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _details_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./details-page.page */ 4859);




const routes = [
    {
        path: '',
        component: _details_page_page__WEBPACK_IMPORTED_MODULE_0__.DetailsPagePage
    }
];
let DetailsPagePageRoutingModule = class DetailsPagePageRoutingModule {
};
DetailsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DetailsPagePageRoutingModule);



/***/ }),

/***/ 1077:
/*!***********************************************************!*\
  !*** ./src/app/pages/details-page/details-page.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailsPagePageModule": () => (/* binding */ DetailsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _details_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./details-page-routing.module */ 3466);
/* harmony import */ var _details_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./details-page.page */ 4859);







let DetailsPagePageModule = class DetailsPagePageModule {
};
DetailsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _details_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetailsPagePageRoutingModule
        ],
        declarations: [_details_page_page__WEBPACK_IMPORTED_MODULE_1__.DetailsPagePage]
    })
], DetailsPagePageModule);



/***/ }),

/***/ 4859:
/*!*********************************************************!*\
  !*** ./src/app/pages/details-page/details-page.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailsPagePage": () => (/* binding */ DetailsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_details_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./details-page.page.html */ 3859);
/* harmony import */ var _details_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./details-page.page.scss */ 3755);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let DetailsPagePage = class DetailsPagePage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    goBack() {
        this._router.navigate(['/home']);
    }
};
DetailsPagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
DetailsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-details-page',
        template: _raw_loader_details_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_details_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DetailsPagePage);



/***/ }),

/***/ 3755:
/*!***********************************************************!*\
  !*** ./src/app/pages/details-page/details-page.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content .top {\n  position: absolute;\n  top: 40px;\n  left: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .description {\n  margin-top: 10px;\n  padding: 20px;\n}\nion-content .description span {\n  color: blue;\n}\nion-content .description h3 {\n  margin-top: 10px;\n  color: red;\n}\nion-content .description p {\n  text-indent: 50px;\n  text-align: justify;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbHMtcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBRFI7QUFFUTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUFaO0FBSVk7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRmhCO0FBT0k7RUFDSSxnQkFBQTtFQUNBLGFBQUE7QUFMUjtBQU1RO0VBQ0ksV0FBQTtBQUpaO0FBTVE7RUFDSSxnQkFBQTtFQUNBLFVBQUE7QUFKWjtBQU1RO0VBQ0ksaUJBQUE7RUFDQSxtQkFBQTtBQUpaIiwiZmlsZSI6ImRldGFpbHMtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuXHJcbiAgICAudG9we1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6NDBweDtcclxuICAgICAgICBsZWZ0OjIwcHg7XHJcbiAgICAgICAgLmJhY2tfZGl2e1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6MjVweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDoyMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICBcclxuICAgIC5kZXNjcmlwdGlvbntcclxuICAgICAgICBtYXJnaW4tdG9wOjEwcHg7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgIGNvbG9yOmJsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGgze1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOjEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOnJlZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcHtcclxuICAgICAgICAgICAgdGV4dC1pbmRlbnQ6IDUwcHg7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ 3859:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/details-page/details-page.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <img src=\"../../../assets/1008.jfif\" style=\"width:100%\">\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"dark\" class=\"back_btn\"></ion-icon>\n    </div>\n  </div>\n\n  <div class=\"description\">\n    <ion-icon color=\"danger\" name=\"time-outline\"></ion-icon> <span> 06, Jan 2022 , 09:00 AM</span>\n    <h3>Rhyme Time: A Night of Poetry</h3>\n    <p>April is also National Poetry Month. Now there is a great theme for a fun family night! Combine poetry readings by students and adults. Invite guest readers and poets. Sell a book of student poems as a fund-raiser. Display portfolios of students' best poetry. Present your oldest students in a poetry slam competition, like teacher Brenda Dyck staged with her students (see the Education World article, A Poetry Slam Cures Midwinter Blahs). For more ideas for great poetry writing activities, don't miss Education World's special Poetry Month archive.</p>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_details-page_details-page_module_ts.js.map