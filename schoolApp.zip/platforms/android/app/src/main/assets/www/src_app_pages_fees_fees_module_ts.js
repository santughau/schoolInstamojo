(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_fees_fees_module_ts"],{

/***/ 5983:
/*!***************************************************!*\
  !*** ./src/app/pages/fees/fees-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeesPageRoutingModule": () => (/* binding */ FeesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _fees_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fees.page */ 776);




const routes = [
    {
        path: '',
        component: _fees_page__WEBPACK_IMPORTED_MODULE_0__.FeesPage
    }
];
let FeesPageRoutingModule = class FeesPageRoutingModule {
};
FeesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FeesPageRoutingModule);



/***/ }),

/***/ 9729:
/*!*******************************************!*\
  !*** ./src/app/pages/fees/fees.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeesPageModule": () => (/* binding */ FeesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _fees_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fees-routing.module */ 5983);
/* harmony import */ var _fees_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fees.page */ 776);







let FeesPageModule = class FeesPageModule {
};
FeesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _fees_routing_module__WEBPACK_IMPORTED_MODULE_0__.FeesPageRoutingModule
        ],
        declarations: [_fees_page__WEBPACK_IMPORTED_MODULE_1__.FeesPage]
    })
], FeesPageModule);



/***/ }),

/***/ 776:
/*!*****************************************!*\
  !*** ./src/app/pages/fees/fees.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeesPage": () => (/* binding */ FeesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_fees_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./fees.page.html */ 7423);
/* harmony import */ var _fees_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fees.page.scss */ 2632);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let FeesPage = class FeesPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    payNow() {
        this.router.navigate(['/pay-online']);
    }
};
FeesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
FeesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-fees',
        template: _raw_loader_fees_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_fees_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FeesPage);



/***/ }),

/***/ 2632:
/*!*******************************************!*\
  !*** ./src/app/pages/fees/fees.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top ion-label {\n  color: #fff;\n  font-size: 22px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: auto;\n  min-height: calc(100% - 80px);\n}\nion-content .content_div .cardData {\n  padding: 30px;\n  border: 1px solid #ccc;\n}\nion-content .content_div .cardData .horizontal-line {\n  padding-bottom: 2px;\n  border-bottom: 3px solid #f0f0f0;\n  color: gray;\n}\nion-content .content_div .paynow {\n  height: 55px;\n  background: #7292cf;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n  text-align: center;\n  color: #fff;\n  line-height: 55px;\n}\nion-content .content_div .paynow ion-icon {\n  float: right;\n  margin-right: 20px;\n  font-size: 24px;\n  line-height: 55px;\n  padding-top: 15px;\n}\nion-content .content_div .downloadClass {\n  margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZlZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLHlGQUFBO0FBQ1I7RUFDSSxrQ0FBQTtFQUNBLDhDQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRVI7QUFEUTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FBR1o7QUFDSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0FBQ1I7QUFBUTtFQUNHLGFBQUE7RUFDQSxzQkFBQTtBQUVYO0FBRFk7RUFDSSxtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsV0FBQTtBQUdoQjtBQUNRO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsK0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBQ1o7QUFDWTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBQ2hCO0FBR087RUFDSSxnQkFBQTtBQURYIiwiZmlsZSI6ImZlZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UG9wcGluczp3Z2h0QDQwMDs2MDAmZGlzcGxheT1zd2FwJyk7XHJcbmlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcbiAgICAudG9we1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tdG9wOjQwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZTtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjMwcHg7XHJcbiAgICAgICAgcGFkZGluZzoyMHB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOjUwcHg7XHJcbiAgICAgICAgaGVpZ2h0OmF1dG87XHJcbiAgICAgICAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gODBweCk7XHJcbiAgICAgICAgLmNhcmREYXRhe1xyXG4gICAgICAgICAgIHBhZGRpbmc6MzBweDtcclxuICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkICNjY2M7XHJcbiAgICAgICAgICAgIC5ob3Jpem9udGFsLWxpbmUge1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDJweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjZjBmMGYwOyBcclxuICAgICAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5wYXlub3d7XHJcbiAgICAgICAgICAgIGhlaWdodDo1NXB4O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiM3MjkyY2Y7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OjU1cHg7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgIGZsb2F0OnJpZ2h0O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDo1NXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy10b3A6MTVweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgLmRvd25sb2FkQ2xhc3N7XHJcbiAgICAgICAgICAgbWFyZ2luLXRvcDoyMHB4O1xyXG4gICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbn0iXX0= */");

/***/ }),

/***/ 7423:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/fees/fees.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div>\n      <ion-buttons slot=\"start\" class=\"menu_btn\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n        <ion-label>Fees Due</ion-label>\n      </ion-buttons>\n    </div>\n\n  </div>\n\n  <div class=\"content_div\">\n\n\n      <div>\n        <div class=\"cardData\">\n          <div class=\"horizontal-line\">\n            <p>Receipt No : <span style=\"float: right\">#1111</span></p>\n         \n          </div>\n       \n          <div class=\"horizontal-line\">\n            <p>Month : <span style=\"float: right\">October</span></p>\n            <p>Payment Date : <span style=\"float: right\">10 Oct 2022</span></p>\n          </div>\n\n          <div >\n            <p>Total Pending Amount : <span style=\"float: right\">$999</span></p>\n          </div>\n          \n        </div>\n        <div class=\"paynow\" (click)=\"payNow()\">\n          Pay Now <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n        </div>\n      </div>\n\n      <div class=\"downloadClass\">\n        <div class=\"cardData\">\n          <div class=\"horizontal-line\">\n            <p>Receipt No : <span style=\"float: right\">#1111</span></p>         \n          </div>\n       \n          <div class=\"horizontal-line\">\n            <p>Month : <span style=\"float: right\">September</span></p>\n            <p>Payment Date : <span style=\"float: right\">10 Sep 2022</span></p>\n            <p>Payment Mode  : <span style=\"float: right\">Cash On Counter</span></p>\n          </div>\n\n          <div >\n            <p>Total Pending Amount : <span style=\"float: right\">$999</span></p>\n          </div>\n          \n        </div>\n        <div class=\"paynow\">\n          Download <ion-icon name=\"download\"></ion-icon>\n        </div>\n      </div>\n\n      <div class=\"downloadClass\">\n        <div class=\"cardData\">\n          <div class=\"horizontal-line\">\n            <p>Receipt No : <span style=\"float: right\">#1111</span></p>         \n          </div>\n       \n          <div class=\"horizontal-line\">\n            <p>Month : <span style=\"float: right\">September</span></p>\n            <p>Payment Date : <span style=\"float: right\">10 Sep 2022</span></p>\n            <p>Payment Mode  : <span style=\"float: right\">Cash On Counter</span></p>\n          </div>\n\n          <div >\n            <p>Total Pending Amount : <span style=\"float: right\">$999</span></p>\n          </div>\n          \n        </div>\n        <div class=\"paynow\">\n          Download <ion-icon name=\"download\"></ion-icon>\n        </div>\n      </div>\n\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_fees_fees_module_ts.js.map