(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_student-list_student-list_module_ts"],{

/***/ 4963:
/*!*******************************************************************!*\
  !*** ./src/app/pages/student-list/student-list-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentListPageRoutingModule": () => (/* binding */ StudentListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _student_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./student-list.page */ 286);




const routes = [
    {
        path: '',
        component: _student_list_page__WEBPACK_IMPORTED_MODULE_0__.StudentListPage
    }
];
let StudentListPageRoutingModule = class StudentListPageRoutingModule {
};
StudentListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], StudentListPageRoutingModule);



/***/ }),

/***/ 4889:
/*!***********************************************************!*\
  !*** ./src/app/pages/student-list/student-list.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentListPageModule": () => (/* binding */ StudentListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _student_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./student-list-routing.module */ 4963);
/* harmony import */ var _student_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./student-list.page */ 286);







let StudentListPageModule = class StudentListPageModule {
};
StudentListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _student_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.StudentListPageRoutingModule
        ],
        declarations: [_student_list_page__WEBPACK_IMPORTED_MODULE_1__.StudentListPage]
    })
], StudentListPageModule);



/***/ }),

/***/ 286:
/*!*********************************************************!*\
  !*** ./src/app/pages/student-list/student-list.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentListPage": () => (/* binding */ StudentListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_student_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./student-list.page.html */ 1837);
/* harmony import */ var _student_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./student-list.page.scss */ 8334);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _popup_component_popup_component_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../popup-component/popup-component.page */ 4419);







let StudentListPage = class StudentListPage {
    constructor(_router, popoverController) {
        this._router = _router;
        this.popoverController = popoverController;
    }
    ngOnInit() {
    }
    goBack() {
        this._router.navigate(['/home']);
    }
    presentPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _popup_component_popup_component_page__WEBPACK_IMPORTED_MODULE_2__.PopupComponentPage,
                event: ev,
                mode: 'ios',
                translucent: true
            });
            yield popover.present();
            const { role } = yield popover.onDidDismiss();
            console.log('onDidDismiss resolved with role', role);
        });
    }
};
StudentListPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.PopoverController }
];
StudentListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-student-list',
        template: _raw_loader_student_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_student_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], StudentListPage);



/***/ }),

/***/ 8334:
/*!***********************************************************!*\
  !*** ./src/app/pages/student-list/student-list.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding-bottom: 50px;\n  min-height: calc(100% - 80px);\n  height: auto;\n}\nion-content .content_div .lbl {\n  margin-top: 10px !important;\n  margin-left: 20px !important;\n  color: #69A03A;\n  font-weight: 600;\n}\nion-content .content_div ion-thumbnail {\n  width: 100px !important;\n  height: 100px !important;\n  background-repeat: no-repeat;\n  background-size: auto;\n  background-size: cover;\n}\nion-content .content_div ion-thumbnail img {\n  border-radius: 10px;\n  width: 100%;\n}\nion-content .content_div ion-label h2 {\n  color: #7292cf;\n}\nion-content .content_div #rate {\n  color: #ccc;\n}\nion-content .content_div .plus {\n  margin-left: 20px;\n  font-weight: 600;\n  padding: 5px;\n}\nion-content .content_div .minus {\n  font-weight: 600;\n  padding: 5px;\n  margin-right: 20px;\n}\nion-content .content_div ion-label ion-icon {\n  margin-right: 10px;\n  color: #69A03A;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0dWRlbnQtbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQURRO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBR1o7QUFGWTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFJaEI7QUFHSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFEUjtBQUVRO0VBQ0ksMkJBQUE7RUFDQSw0QkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQUFaO0FBRVE7RUFDSSx1QkFBQTtFQUNBLHdCQUFBO0VBRUEsNEJBQUE7RUFDQSxxQkFBQTtFQUNBLHNCQUFBO0FBRFo7QUFFWTtFQUNJLG1CQUFBO0VBQ0EsV0FBQTtBQUFoQjtBQUlZO0VBQ0ksY0FBQTtBQUZoQjtBQU1RO0VBQ0ksV0FBQTtBQUpaO0FBTVE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQUpaO0FBT1E7RUFFSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQU5aO0FBVVk7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUFSaEIiLCJmaWxlIjoic3R1ZGVudC1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVBvcHBpbnM6d2dodEA0MDA7NjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5pb24tY29udGVudHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM3MjkyY2YsIzI4NTVhZSApO1xyXG4gICAgLnRvcHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo0MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgLmJhY2tfZGl2e1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjI1cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZTtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjMwcHg7ICAgICAgIFxyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOjUwcHg7XHJcbiAgICAgICAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gODBweCk7XHJcbiAgICAgICAgaGVpZ2h0OmF1dG87XHJcbiAgICAgICAgLmxibHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDoyMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGNvbG9yOiM2OUEwM0E7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi10aHVtYm5haWx7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGhlaWdodDoxMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAvLyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvc3R1ZGVudC8xLmpwZycpO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGF1dG87XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgICAgIGltZ3tcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgfSAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgIGgye1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IzcyOTJjZjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgICNyYXRle1xyXG4gICAgICAgICAgICBjb2xvcjojY2NjO1xyXG4gICAgICAgIH1cclxuICAgICAgICAucGx1c3tcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgcGFkZGluZzo1cHg7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICAubWludXN7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBwYWRkaW5nOjVweDtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgXHJcbiAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDoxMHB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IzY5QTAzQTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG59Il19 */");

/***/ }),

/***/ 1837:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/student-list/student-list.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Student List</ion-label>\n    </div>\n   \n  </div>\n\n  <div class=\"content_div\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size = 12>\n          <p class=\"lbl\">Class XI</p>\n          <ion-list style=\"overflow-y: scroll !important; height: 100%;\">\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/1.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/2.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/12.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/13.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/14.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/8.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/4.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n            <ion-item>\n              <ion-thumbnail slot=\"start\" [style.backgroundImage]=\"'url(/assets/student/10.jpg)'\">\n              </ion-thumbnail>\n              <ion-label>\n                <h2>Santosh Ashokrao Sontakke<span style=\"float: right\">\n                  <ion-icon name=\"ellipsis-vertical-outline\" (click)=\"presentPopover($event)\"></ion-icon>\n                  </span></h2>\n                <p id=\"rate\">Computer Science Final Year</p>\n                <p id=\"rate\">DOB  Aug 23,1980</p>\n                <p>Roll No 001</p>\n              </ion-label>\n            </ion-item>\n\n           \n           \n          </ion-list>\n        </ion-col>\n\n        \n       \n      </ion-row>\n    </ion-grid>\n  </div>\n  \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_student-list_student-list_module_ts.js.map