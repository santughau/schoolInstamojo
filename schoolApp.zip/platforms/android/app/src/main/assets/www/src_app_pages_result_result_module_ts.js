(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_result_result_module_ts"],{

/***/ 3370:
/*!*******************************************************!*\
  !*** ./src/app/pages/result/result-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultPageRoutingModule": () => (/* binding */ ResultPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _result_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./result.page */ 1242);




const routes = [
    {
        path: '',
        component: _result_page__WEBPACK_IMPORTED_MODULE_0__.ResultPage
    }
];
let ResultPageRoutingModule = class ResultPageRoutingModule {
};
ResultPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ResultPageRoutingModule);



/***/ }),

/***/ 8766:
/*!***********************************************!*\
  !*** ./src/app/pages/result/result.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultPageModule": () => (/* binding */ ResultPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _result_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./result-routing.module */ 3370);
/* harmony import */ var _result_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./result.page */ 1242);







let ResultPageModule = class ResultPageModule {
};
ResultPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _result_routing_module__WEBPACK_IMPORTED_MODULE_0__.ResultPageRoutingModule
        ],
        declarations: [_result_page__WEBPACK_IMPORTED_MODULE_1__.ResultPage]
    })
], ResultPageModule);



/***/ }),

/***/ 1242:
/*!*********************************************!*\
  !*** ./src/app/pages/result/result.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultPage": () => (/* binding */ ResultPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_result_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./result.page.html */ 6753);
/* harmony import */ var _result_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./result.page.scss */ 6797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let ResultPage = class ResultPage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    goBack() {
        this._router.navigate(['/home']);
    }
};
ResultPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ResultPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-result',
        template: _raw_loader_result_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_result_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResultPage);



/***/ }),

/***/ 6797:
/*!***********************************************!*\
  !*** ./src/app/pages/result/result.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .top .button ion-icon {\n  font-size: 24px;\n  color: #fff;\n}\nion-content .grade {\n  color: #fff;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin-top: 25px;\n  flex-direction: column;\n}\nion-content .grade p:nth-child(1) {\n  font-size: 50px;\n  margin-bottom: -10px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 10px;\n  padding: 20px;\n  padding-bottom: 50px;\n  height: calc(100% - 200px);\n}\nion-content .content_div p {\n  text-align: center;\n  color: #ccc;\n}\nion-content .content_div h2 {\n  text-align: center;\n}\nion-content .content_div .myTable {\n  padding: 20px;\n  border: 1px solid #ccc;\n  height: auto;\n  border-radius: 10px;\n}\nion-content .content_div .myTable .data tr .ss {\n  background-color: red !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc3VsdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQURRO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBR1o7QUFDWTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFDaEI7QUFJWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FBRmhCO0FBTUk7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBSlI7QUFLUTtFQUNJLGVBQUE7RUFDQSxvQkFBQTtBQUhaO0FBTUk7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLDBCQUFBO0FBSlI7QUFNUTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtBQUpaO0FBTVE7RUFDSSxrQkFBQTtBQUpaO0FBTVE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFKWjtBQU9vQjtFQUNJLGdDQUFBO0FBTHhCIiwiZmlsZSI6InJlc3VsdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Qb3BwaW5zOndnaHRANDAwOzYwMCZkaXNwbGF5PXN3YXAnKTtcclxuaW9uLWNvbnRlbnR7XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgLS1iYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgjNzI5MmNmLCMyODU1YWUgKTtcclxuICAgIC50b3B7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgIG1hcmdpbi10b3A6NDBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gICAgICAgIC5iYWNrX2RpdntcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjI1cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmJ1dHRvbntcclxuICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmdyYWRle1xyXG4gICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOmNvbHVtbjtcclxuICAgICAgICBwOm50aC1jaGlsZCgxKXtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA1MHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOi0xMHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5jb250ZW50X2RpdntcclxuICAgICAgICBiYWNrZ3JvdW5kOndoaXRlO1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMzVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOjI1cHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MTBweDtcclxuICAgICAgICBwYWRkaW5nOjIwcHg7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206NTBweDtcclxuICAgICAgICBoZWlnaHQ6Y2FsYygxMDAlIC0gMjAwcHgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHB7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgY29sb3I6I2NjYztcclxuICAgICAgICB9XHJcbiAgICAgICAgaDJ7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLm15VGFibGV7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCAjY2NjO1xyXG4gICAgICAgICAgICBoZWlnaHQ6YXV0bztcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgICAgLmRhdGF7XHJcbiAgICAgICAgICAgICAgICB0cntcclxuICAgICAgICAgICAgICAgICAgICAuc3N7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJlZCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbn0iXX0= */");

/***/ }),

/***/ 6753:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/result/result.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Result</ion-label>\n    </div>\n    <div class=\"button\">\n      <ion-icon name=\"share-social-outline\"></ion-icon>\n    </div>\n  </div>\n\n  <div class=\"grade\">\n    <p>99.85 %</p>\n    <p>Grade A+</p>\n  </div>\n  <div class=\"content_div\">\n    <p>You are Excellent,</p>\n    <h2>Yamini Sontakke !!</h2>\n    \n    <div class=\"myTable\">\n      <div class=\"data\">\n        <table class=\"table table-bordered table-condensed borderless\">\n          <tbody>\n            <tr class=\"info\">\n              <th>English</th>\n              <th class=\"ss text-white text-center\">100</th>\n              <th class=\"bg-warning text-white text-center\">74 - B</th>\n            </tr>\n            <tr class=\"info\">\n              <th>Computer </th>\n              <th class=\"ss text-white text-center\">100</th>\n              <th class=\"bg-warning text-white text-center\">74 - B</th>\n            </tr>\n            <tr class=\"info\">\n              <th>Science</th>\n              <th class=\"ss text-white text-center\">100</th>\n              <th class=\"bg-warning text-white text-center\">74 - B</th>\n            </tr>\n            <tr class=\"info\">\n              <th>Math</th>\n              <th class=\"ss text-white text-center\">100</th>\n              <th class=\"bg-warning text-white text-center\">74 - B</th>\n            </tr>\n            <tr class=\"info\">\n              <th >Social Study</th>\n              <th class=\"ss text-white text-center\">100</th>\n              <th class=\"bg-warning text-white text-center\">74 - B</th>\n          </tr>\n          <tr class=\"info\">\n            <th >Geography</th>\n            <th class=\"ss text-white text-center\">100</th>\n            <th class=\"bg-warning text-white text-center\">74 - B</th>\n        </tr>\n          </tbody>\n        </table>\n        <ion-button expand=\"block\"  shape=\"round\">Download PDF &nbsp; &nbsp;<ion-icon name=\"document-outline\"></ion-icon></ion-button>\n      </div>\n\n    </div>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_result_result_module_ts.js.map