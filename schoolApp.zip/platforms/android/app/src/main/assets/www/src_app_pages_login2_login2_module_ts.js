(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_login2_login2_module_ts"],{

/***/ 8620:
/*!*******************************************************!*\
  !*** ./src/app/pages/login2/login2-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Login2PageRoutingModule": () => (/* binding */ Login2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _login2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login2.page */ 3160);




const routes = [
    {
        path: '',
        component: _login2_page__WEBPACK_IMPORTED_MODULE_0__.Login2Page
    }
];
let Login2PageRoutingModule = class Login2PageRoutingModule {
};
Login2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Login2PageRoutingModule);



/***/ }),

/***/ 2565:
/*!***********************************************!*\
  !*** ./src/app/pages/login2/login2.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Login2PageModule": () => (/* binding */ Login2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _login2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login2-routing.module */ 8620);
/* harmony import */ var _login2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login2.page */ 3160);







let Login2PageModule = class Login2PageModule {
};
Login2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Login2PageRoutingModule
        ],
        declarations: [_login2_page__WEBPACK_IMPORTED_MODULE_1__.Login2Page]
    })
], Login2PageModule);



/***/ }),

/***/ 3160:
/*!*********************************************!*\
  !*** ./src/app/pages/login2/login2.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Login2Page": () => (/* binding */ Login2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_login2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login2.page.html */ 2942);
/* harmony import */ var _login2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login2.page.scss */ 7476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let Login2Page = class Login2Page {
    constructor(_router) {
        this._router = _router;
        this.registerData = {
            email: "",
            password: "",
            confirmPassword: ""
        };
        this.type = true;
    }
    ngOnInit() {
    }
    changeType() {
        this.type = !this.type;
    }
    goToHome() {
        this._router.navigate(['/home']);
    }
};
Login2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Login2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-login2',
        template: _raw_loader_login2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Login2Page);



/***/ }),

/***/ 7476:
/*!***********************************************!*\
  !*** ./src/app/pages/login2/login2.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .main img {\n  margin-top: 60px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: -15px;\n  padding-top: 30px;\n  padding: 20px;\n  min-height: calc(100% - 100px);\n  height: auto;\n}\nion-content .content_div #para {\n  color: black;\n  margin-left: 25px;\n  font-size: 28px;\n  z-index: 88;\n}\nion-content .content_div #para span {\n  font-weight: bold;\n}\nion-content .content_div h6 {\n  margin-left: 25px;\n  font-size: 18px;\n  margin-top: -30px;\n  color: #cccccc;\n  padding-bottom: 10px;\n}\nion-content .content_div .btn {\n  margin-top: 25px;\n  width: 100%;\n}\nion-content .content_div .btn button {\n  background: red;\n  color: #fff;\n  width: 100%;\n  height: 45px;\n  border-radius: 5px;\n  font-size: 20px;\n}\nion-content .content_div .btn button ion-icon {\n  float: right;\n  margin-right: 10px;\n}\nion-content .content_div .btn p {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUVRO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUFaO0FBS0k7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLDRCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7QUFIUjtBQUlRO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUFGWjtBQUdZO0VBQ0ksaUJBQUE7QUFEaEI7QUFJUTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBRlo7QUFJUTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtBQUZaO0FBR1k7RUFDRyxlQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBRGY7QUFFZTtFQUNDLFlBQUE7RUFDQSxrQkFBQTtBQUFoQjtBQUdZO0VBQ0ksWUFBQTtBQURoQiIsImZpbGUiOiJsb2dpbjIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9UG9wcGluczp3Z2h0QDQwMDs2MDAmZGlzcGxheT1zd2FwJyk7XHJcbmlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIC0tYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzcyOTJjZiwjMjg1NWFlICk7XHJcblxyXG4gICAgLm1haW57XHJcbiAgICAgICAgaW1ne1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOjYwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZTtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDotMTVweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDozMHB4O1xyXG4gICAgICAgIHBhZGRpbmc6MjBweDtcclxuICAgICAgICBtaW4taGVpZ2h0OmNhbGMoMTAwJSAtIDEwMHB4KTtcclxuICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgICAgI3BhcmF7XHJcbiAgICAgICAgICAgIGNvbG9yOmJsYWNrO1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDoyNXB4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6MjhweDtcclxuICAgICAgICAgICAgei1pbmRleDogODg7XHJcbiAgICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDpib2xkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGg2e1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDoyNXB4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6MThweDsgXHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6LTMwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiNjY2NjY2M7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOjEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5idG57XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6MjVweDtcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgYnV0dG9ue1xyXG4gICAgICAgICAgICAgICBiYWNrZ3JvdW5kOnJlZDsgXHJcbiAgICAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgICAgIGhlaWdodDo0NXB4O1xyXG4gICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOjVweDtcclxuICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDoxMHB4O1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 2942:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login2/login2.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"main\">\n    <img src=\"../../../assets/002.png\" />\n  </div>\n\n  <div class=\"content_div\">\n    <p id=\"para\">Hi <span>Student</span></p>\n    <h6>Sign in to continue</h6>\n    <form #registration=\"ngForm\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Mobile Number / Email</ion-label>\n        <ion-input type=\"email\" placeholder=\"Email\" name=\"email\" #email=\"ngModel\" [(ngModel)]=\"registerData.email\"\n          required email></ion-input>\n      </ion-item>\n      <div *ngIf=\"email.invalid && email.touched \">\n        <ion-text color=\"danger text-center\">\n          <h4 style=\"padding-left: 20px; margin-top: 10px;\">E-mail Required</h4>\n        </ion-text>\n      </div>\n\n      \n      <div class=\"ion-margin-vertical\">\n        <ion-item>\n          <ion-label position=\"floating\">Password</ion-label>\n          <ion-input [type]=\"type ? 'password' : 'text'\" placeholder=\"Password\" name=\"password\" #password=\"ngModel\"\n            [(ngModel)]=\"registerData.password\" required></ion-input>\n          <!-- <ion-icon slot=\"end\" name=\"eye-outline\" class=\"ion-align-self-center\"></ion-icon> -->\n\n\n          <ion-icon class=\"ion-align-self-center\" name=\"eye-outline\" slot=\"end\" color=\"medium\" (click)=\"changeType()\"\n              [name]=\"type ? 'eye-outline' : 'eye-off-outline'\"></ion-icon>\n        </ion-item>\n      </div>\n\n      <div *ngIf=\"password.invalid && password.touched \">\n        <ion-text color=\"danger text-center\">\n          <h4 style=\"padding-left: 20px; margin-top: 10px;\">Password Required</h4>\n        </ion-text>\n      </div>\n\n\n      <div class=\"ion-margin-vertical\">\n        <ion-item>\n          <ion-label position=\"floating\">Confirm Password</ion-label>\n          <ion-input [type]=\"type ? 'password' : 'text'\" placeholder=\"Confirm Password\" name=\"confirmPassword\" #confirmPassword=\"ngModel\"\n            [(ngModel)]=\"registerData.confirmPassword\" required></ion-input>\n          <!-- <ion-icon slot=\"end\" name=\"eye-outline\" class=\"ion-align-self-center\"></ion-icon> -->\n\n\n          <ion-icon class=\"ion-align-self-center\" name=\"eye-outline\" slot=\"end\" color=\"medium\" (click)=\"changeType()\"\n              [name]=\"type ? 'eye-outline' : 'eye-off-outline'\"></ion-icon>\n        </ion-item>\n      </div>\n\n      <div *ngIf=\"password.invalid && password.touched \">\n        <ion-text color=\"danger text-center\">\n          <h4 style=\"padding-left: 20px; margin-top: 10px;\">Confirm Password Required</h4>\n        </ion-text>\n      </div>\n\n\n    </ion-list>\n\n    <div class=\"btn\">\n      <ion-button color=\"danger\" (click)=\"goToHome()\" expand=\"block\" [disabled]=\"registration.invalid\">Register\n        <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n      </ion-button>\n      <p>Create Account</p>\n    </div>\n  </form>\n  </div>\n\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_login2_login2_module_ts.js.map