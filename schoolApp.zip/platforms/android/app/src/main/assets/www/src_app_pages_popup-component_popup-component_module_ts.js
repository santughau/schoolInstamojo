(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_popup-component_popup-component_module_ts"],{

/***/ 6081:
/*!*************************************************************************!*\
  !*** ./src/app/pages/popup-component/popup-component-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopupComponentPageRoutingModule": () => (/* binding */ PopupComponentPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _popup_component_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./popup-component.page */ 4419);




const routes = [
    {
        path: '',
        component: _popup_component_page__WEBPACK_IMPORTED_MODULE_0__.PopupComponentPage
    }
];
let PopupComponentPageRoutingModule = class PopupComponentPageRoutingModule {
};
PopupComponentPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PopupComponentPageRoutingModule);



/***/ }),

/***/ 571:
/*!*****************************************************************!*\
  !*** ./src/app/pages/popup-component/popup-component.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopupComponentPageModule": () => (/* binding */ PopupComponentPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _popup_component_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./popup-component-routing.module */ 6081);
/* harmony import */ var _popup_component_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./popup-component.page */ 4419);







let PopupComponentPageModule = class PopupComponentPageModule {
};
PopupComponentPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _popup_component_routing_module__WEBPACK_IMPORTED_MODULE_0__.PopupComponentPageRoutingModule
        ],
        declarations: [_popup_component_page__WEBPACK_IMPORTED_MODULE_1__.PopupComponentPage]
    })
], PopupComponentPageModule);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_popup-component_popup-component_module_ts.js.map