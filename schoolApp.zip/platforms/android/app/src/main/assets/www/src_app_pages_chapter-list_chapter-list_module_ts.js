(self["webpackChunkschoolApp"] = self["webpackChunkschoolApp"] || []).push([["src_app_pages_chapter-list_chapter-list_module_ts"],{

/***/ 7632:
/*!*******************************************************************!*\
  !*** ./src/app/pages/chapter-list/chapter-list-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChapterListPageRoutingModule": () => (/* binding */ ChapterListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _chapter_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chapter-list.page */ 5225);




const routes = [
    {
        path: '',
        component: _chapter_list_page__WEBPACK_IMPORTED_MODULE_0__.ChapterListPage
    }
];
let ChapterListPageRoutingModule = class ChapterListPageRoutingModule {
};
ChapterListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChapterListPageRoutingModule);



/***/ }),

/***/ 722:
/*!***********************************************************!*\
  !*** ./src/app/pages/chapter-list/chapter-list.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChapterListPageModule": () => (/* binding */ ChapterListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _chapter_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chapter-list-routing.module */ 7632);
/* harmony import */ var _chapter_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chapter-list.page */ 5225);







let ChapterListPageModule = class ChapterListPageModule {
};
ChapterListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _chapter_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChapterListPageRoutingModule
        ],
        declarations: [_chapter_list_page__WEBPACK_IMPORTED_MODULE_1__.ChapterListPage]
    })
], ChapterListPageModule);



/***/ }),

/***/ 5225:
/*!*********************************************************!*\
  !*** ./src/app/pages/chapter-list/chapter-list.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChapterListPage": () => (/* binding */ ChapterListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_chapter_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./chapter-list.page.html */ 3005);
/* harmony import */ var _chapter_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chapter-list.page.scss */ 4068);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9535);





let ChapterListPage = class ChapterListPage {
    constructor(_router) {
        this._router = _router;
        this.segId = 'Chapters';
    }
    ngOnInit() {
        this.chapters = [
            {
                img: 'assets/light.jpg',
                name: 'Theory of Light',
                per: 90
            },
            {
                img: 'assets/water.jpg',
                name: 'Theory of Water',
                per: 40
            },
            {
                img: 'assets/motion.jpg',
                name: 'Theory of Motion',
                per: 50
            },
            {
                img: 'assets/sound.jpg',
                name: 'Theory of Sound',
                per: 65
            },
            {
                img: 'assets/sky.jpg',
                name: 'Theory of Sky',
                per: 75
            },
            {
                img: 'assets/energy.jpg',
                name: 'Theory of Energy',
                per: 45
            },
        ];
    }
    goBack() {
        this._router.navigate(['/subject']);
    }
    goToQuiz() {
        console.log("quiz");
        this._router.navigate(['/quiz']);
    }
};
ChapterListPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ChapterListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-chapter-list',
        template: _raw_loader_chapter_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_chapter_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ChapterListPage);



/***/ }),

/***/ 4068:
/*!***********************************************************!*\
  !*** ./src/app/pages/chapter-list/chapter-list.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\");\nion-content {\n  font-family: \"Poppins\", sans-serif;\n  --background:linear-gradient(#7292cf,#2855ae );\n}\nion-content .top {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-top: 40px;\n  margin-left: 20px;\n  margin-right: 20px;\n}\nion-content .top .back_div {\n  font-size: 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-content .top .back_div ion-label {\n  color: #fff;\n  font-size: 25px;\n  padding-left: 20px;\n}\nion-content .content_div {\n  background: white;\n  width: 100%;\n  border-top-right-radius: 35px;\n  border-top-left-radius: 35px;\n  margin-top: 25px;\n  padding-top: 30px;\n  padding-bottom: 50px;\n  min-height: calc(100% - 80px);\n  height: auto;\n}\nion-content .content_div .main_content_div {\n  padding: 16px;\n}\nion-content .content_div .main_content_div ion-label {\n  display: block;\n}\nion-content .content_div .main_content_div .card_div {\n  padding: 10px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 10px;\n  margin-bottom: 15px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  position: relative;\n}\nion-content .content_div .main_content_div .card_div .download {\n  width: 18px;\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  z-index: 99999;\n}\nion-content .content_div .main_content_div .card_div .round_div {\n  height: 50px;\n  width: 50px;\n  border-radius: 50px;\n  min-width: 50px;\n  background: linear-gradient(#7292cf, #2855ae);\n  position: relative;\n}\nion-content .content_div .main_content_div .card_div .round_div ion-icon {\n  position: absolute;\n  color: white;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 30px;\n}\nion-content .content_div .main_content_div .card_div .content_divA {\n  width: 100%;\n  padding-left: 10px;\n  position: relative;\n}\nion-content .content_div .main_content_div .card_div .content_divA .title_lbl {\n  font-size: 16px;\n  font-weight: 600;\n  color: #b91d73;\n}\nion-content .content_div .main_content_div .card_div .content_divA .small_lbl {\n  font-size: 12px;\n  color: gray;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\nion-content .content_div .main_content_div .card_div .content_divA .abs_lbl {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  font-size: 12px;\n  color: #b91d73;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXB0ZXItbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQVEseUZBQUE7QUFDUjtFQUNJLGtDQUFBO0VBQ0EsOENBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQURRO0VBQ0ksZUFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBR1o7QUFGWTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFJaEI7QUFHSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFEUjtBQUVRO0VBQ0ksYUFBQTtBQUFaO0FBRVk7RUFDSSxjQUFBO0FBQWhCO0FBR1k7RUFDSSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQURoQjtBQUVnQjtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsY0FBQTtBQUFwQjtBQUVnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsNkNBQUE7RUFDQSxrQkFBQTtBQUFwQjtBQUNvQjtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQ3hCO0FBRWdCO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFBcEI7QUFDb0I7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQ3hCO0FBRW9CO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFBeEI7QUFFb0I7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFBeEIiLCJmaWxlIjoiY2hhcHRlci1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVBvcHBpbnM6d2dodEA0MDA7NjAwJmRpc3BsYXk9c3dhcCcpO1xyXG5pb24tY29udGVudHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICAtLWJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM3MjkyY2YsIzI4NTVhZSApO1xyXG4gICAgLnRvcHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDo0MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OjIwcHg7XHJcbiAgICAgICAgLmJhY2tfZGl2e1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6Y2VudGVyO1xyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjI1cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICAuY29udGVudF9kaXZ7XHJcbiAgICAgICAgYmFja2dyb3VuZDp3aGl0ZTtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoyNXB4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOjMwcHg7ICAgICAgIFxyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOjUwcHg7XHJcbiAgICAgICAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gODBweCk7XHJcbiAgICAgICAgaGVpZ2h0OmF1dG87XHJcbiAgICAgICAgLm1haW5fY29udGVudF9kaXZ7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6MTZweDtcclxuICAgICAgICBcclxuICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgLmNhcmRfZGl2e1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICAgICAgICAgIC5kb3dubG9hZHtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMThweDtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgICAgICByaWdodDogMTBweDtcclxuICAgICAgICAgICAgICAgICAgICB0b3A6MTBweDtcclxuICAgICAgICAgICAgICAgICAgICB6LWluZGV4OiA5OTk5OTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5yb3VuZF9kaXZ7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OjUwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6NTBweDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOjUwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgbWluLXdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjNzI5MmNmLCMyODU1YWUgKTtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OjUwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOjUwJTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTozMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC5jb250ZW50X2RpdkF7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6MTBweDtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICAgICAgLnRpdGxlX2xibHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjojYjkxZDczO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAuc21hbGxfbGJse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOmdyYXk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAuYWJzX2xibHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6I2I5MWQ3M1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICBcclxufVxyXG4gICAgXHJcbn0iXX0= */");

/***/ }),

/***/ 3005:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chapter-list/chapter-list.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div class=\"top\">\n    <div class=\"back_div\">\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" color=\"light\" class=\"back_btn\"></ion-icon>\n      <ion-label>Select Chapter</ion-label>\n    </div>\n   \n  </div>\n\n  <div class=\"content_div\">\n    <div class=\"main_content_div\">\n        <div class=\"card_div\" *ngFor=\"let item of chapters\" (click)=\"goToQuiz()\">\n          <img src=\"../../../../assets/download.png\" class=\"download\" />\n  \n          <div class=\"round_div\">\n            <ion-icon name=\"checkmark-circle-outline\"></ion-icon>\n          </div>\n  \n          <div class=\"content_divA\">\n            <ion-label class=\"title_lbl\">{{item.name}}</ion-label>\n            <ion-label class=\"small_lbl\">{{item.name}}</ion-label>\n            <ion-progress-bar value=\"{{item.per/100}}\"></ion-progress-bar>\n            <ion-label class=\"small_lbl\">Download Notes Of This Chapter</ion-label>\n            <ion-label class=\"abs_lbl\">{{item.per}}</ion-label>\n          </div>\n        </div>\n    </div>\n   \n  </div>\n  \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_chapter-list_chapter-list_module_ts.js.map