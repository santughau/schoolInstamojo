import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ask-doubt',
  templateUrl: './ask-doubt.page.html',
  styleUrls: ['./ask-doubt.page.scss'],
})
export class AskDoubtPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
